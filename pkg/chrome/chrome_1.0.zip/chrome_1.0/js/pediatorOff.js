function PediatorOff() {
	location.reload();
}

PediatorOff();
